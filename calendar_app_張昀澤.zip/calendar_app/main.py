from ui.main_window import MainWindow

def main():
    """アプリケーションを起動します。"""
    app = MainWindow()
    app.run()

if __name__ == "__main__":
    main()
